#!/bin/bash
# PhrozenGo launcher script with local libraries
export LD_LIBRARY_PATH=/home/mks/PhrozenGo/tutk
exec /home/mks/PhrozenGo/phrozen-go-release "$@"